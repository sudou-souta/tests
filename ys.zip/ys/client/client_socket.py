import socket
import sys
import os

def client_socket():
    home = os.environ["HOME"]
    # ip_socket
    f = open(f"{home}/ys/ip.txt","r")
    ip = f.read()
    f.close()
    if len(ip) > 7:
        print("接続できません")
        sys.exit(1)
    client = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
    server = (ip,40)
    try:
        client.connect(server)
    except:
        print("接続できません")
        sys.exit(1)
    return client