import sys
import os
import client_socket
import req_create

if len(sys.argv) != 3:
    print("引数が少なすぎます")
    sys.exit(1)

channel = sys.argv[1]
message = sys.argv[2]

# home
home = os.environ["HOME"]

# client_socket
client = client_socket.client_socket()
req = req_create.req_create_message(channel,message)
client.send(req)