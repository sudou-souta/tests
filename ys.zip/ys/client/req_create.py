def req_create_message(channel,message):
    req_text = f"m;{channel}|{message}"
    req_decode = req_text.decode()
    return req_decode