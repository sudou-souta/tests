import socket

def server_socket():
    server = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
    server.bind(("",40))
    server.listen(1000)
    return server