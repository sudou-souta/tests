import sys
import os 
import socket
def ip_socket():
    home = os.environ["HOME"]
    # ip_socket
    f = open(f"{home}/ys/ip.txt","r")
    ip = f.read()
    f.close()
    if len(ip) > 7:
        print("接続できません")
        sys.exit(1)
    ip_socket = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
    try:
        ip_socket.connect((ip,40))
    except:
        print("エラー：接続できません")
        sys.exit(1)
    return ip_socket