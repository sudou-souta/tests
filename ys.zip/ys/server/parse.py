def parser(req):
    # type;channel|message
    # type;query
    req = list(req)
    req_len = len(req)-1
    count = 0
    req_type = req[count]
    if req_type != "m":
        return False
    else:
        count += 1
        if req[count] != ";":
            return False
        else:
            count += 1
            channel = ""
            while True:
                string = req[count]
                if string == "|":
                    count += 1
                    break
                else:
                    channel += string
            message = ""
            while True:
                if count == req_len:
                    break
                string = req[count]
                message += string
            return [req_type,channel,message]